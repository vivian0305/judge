# 第三届阿里巴巴中间件性能挑战赛初赛程序

### 进程内消息引擎

初赛最终排名：6/1959	


[初赛题目详细链接](https://code.aliyun.com/middlewarerace2017/open-messaging-demo?spm=5176.100068.555.1.Kz5MUL)  


![Rank](rank.png)


